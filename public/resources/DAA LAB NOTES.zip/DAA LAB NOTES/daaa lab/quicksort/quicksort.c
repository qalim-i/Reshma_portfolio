#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#define max 10000

void exch(int *p,int *q)
{
int temp=*p;
*p=*q;
*q=temp;
}
void quicksort(int a[],int low,int high)
{
int i,j,key,k;
if(low>=high)
return;
key=low;
i=low+1;
j=high;
while(i<=j)
{
while(a[i]<=a[key])
i=i+1;
while(a[j]>a[key])
j=j-1;
if(i<j)
exch(&a[i],&a[j]);
}
exch(&a[j],&a[key]);
quicksort(a,low,j-1);
quicksort(a,j+1,high);
}
int main()
{
int n,y[max];
int i;
long counter;
float seconds;
clock_t start,finish;
printf("Enter the no of elements to be sorted\n");
scanf("%d", &n);
for(i=1;i<=n;i++)
{
y[i]=rand()%10;
printf("%d ",y[i]);
}

start=clock();
counter=0;
while(clock()-start<100)
{
counter++;
quicksort(y,1,n);
}
finish=clock();
seconds=(finish-start)/18.26;
printf("The sorted elements:\n");
for(i=1;i<=n;i++)
printf("%d ", y[i]);
printf("\n\tTime per search= %f", (float)seconds/counter);
}


